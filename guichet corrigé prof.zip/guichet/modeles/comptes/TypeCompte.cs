﻿namespace guichet.modeles.comptes
{
    public enum TypeCompte
    {
        CompteCheque,
        CompteEpargne
    }
}
