﻿namespace guichet.modeles.transactions
{
    public enum TypeTransaction
    {
        Depot,
        Retrait
    }
}
